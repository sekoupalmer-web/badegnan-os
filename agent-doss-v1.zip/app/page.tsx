"use client";

import { useState } from "react";

const menu = [
  ["🤖", "Agent"],
  ["📣", "Publications"],
  ["🔎", "Prospects"],
  ["👥", "Clients"],
  ["💰", "Ventes"],
  ["📅", "Calendrier"],
  ["📊", "Statistiques"],
];

export default function Home() {
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState<string[]>([]);

  function sendMessage() {
    const value = message.trim();
    if (!value) return;
    setSent((items) => [...items, value]);
    setMessage("");
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="logo">D</div>
          <div>
            <strong>AGENT DOSS</strong>
            <span>Votre agent IA</span>
          </div>
        </div>

        <nav>
          {menu.map(([icon, label], index) => (
            <button className={index === 0 ? "nav active" : "nav"} key={label}>
              <span>{icon}</span>{label}
            </button>
          ))}
        </nav>

        <button className="settings">⚙️ Paramètres</button>
      </aside>

      <section className="content">
        <header className="topbar">
          <div>
            <p className="eyebrow">TABLEAU DE BORD</p>
            <h1>Bonjour 👋</h1>
            <p className="muted">Que voulez-vous qu’Agent DOSS fasse pour vous ?</p>
          </div>
          <div className="status"><i /> Agent opérationnel</div>
        </header>

        <section className="hero">
          <div className="heroIcon">🤖</div>
          <div>
            <h2>Je suis Agent DOSS</h2>
            <p>Je peux vous aider à travailler, communiquer, trouver des prospects et organiser vos ventes.</p>
          </div>
        </section>

        <section className="cards">
          <div className="card"><span>📣</span><b>Publications</b><small>Créer et organiser votre contenu</small></div>
          <div className="card"><span>🔎</span><b>Prospection</b><small>Organiser vos prospects</small></div>
          <div className="card"><span>💰</span><b>Ventes</b><small>Suivre vos opportunités</small></div>
        </section>

        <section className="assistant">
          <div className="assistantHead">
            <div><h2>Parler à Agent DOSS</h2><p>Donnez-moi une mission en langage naturel.</p></div>
          </div>

          <div className="chat">
            {sent.length === 0 ? (
              <div className="empty">
                <div>💬</div>
                <b>Votre première mission</b>
                <p>Exemple : « Prépare mes publications de la semaine. »</p>
              </div>
            ) : sent.map((item, i) => (
              <div className="bubble" key={i}>{item}</div>
            ))}
          </div>

          <div className="composer">
            <input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
              placeholder="Écrivez une mission pour Agent DOSS..."
            />
            <button onClick={sendMessage}>Envoyer →</button>
          </div>
        </section>
      </section>
    </main>
  );
}
