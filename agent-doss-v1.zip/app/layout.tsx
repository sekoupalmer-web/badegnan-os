import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Agent DOSS",
  description: "Votre agent IA pour travailler, vendre et automatiser."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}
