# AGENT DOSS V1

Base de départ d'une plateforme d'agent IA multi-utilisateur.

## Objectif
Agent DOSS doit devenir un assistant capable d'aider son propriétaire et ses clients :
- publications et marketing
- prospection
- CRM
- ventes
- tâches et automatisations
- statistiques

## Stack de départ
- Next.js + TypeScript
- Interface responsive mobile
- Architecture préparée pour API/IA, base de données et authentification
- Les connexions aux réseaux sociaux et le moteur IA seront ajoutés dans les prochaines étapes.

## Lancer
```bash
npm install
npm run dev
```
Puis ouvrir http://localhost:3000
